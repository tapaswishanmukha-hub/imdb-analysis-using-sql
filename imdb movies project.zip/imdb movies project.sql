## a)	Can you get all data about movies? 
select * from  movies ;
## b)	How do you get all data about directors?
select * from directors;
### c)	Check how many movies are present in IMDB.
select count(*) as total_movies from movies;
### d)	Find these 3 directors: James Cameron ; Luc Besson ; John Woo
select * from directors where name in ('James Cameron' , 'Luc Besson' , 'John Woo');
### e)	Find all directors with name starting with S.
select * from directors where name  like 'S%';
### f)	Count female directors.
select count(*) as female_directors from directors
where gender = 1 ;
### g)	Find the name of the 10th first women directors?
select name from directors where gender = 1
limit 9, 1;
### h)	What are the 3 most popular movies?
select *  from movies;
select * from movies order by popularity desc limit 3;
### ) Find the 3 most bankable movies
select * from movies order by revenue desc limit 3;
### j) Find the movie with the highest average vote since January 1, 2000
select * from movies where 
release_date >= '2000-01-01'
order by vote_average desc
limit 1;
select * from movies order by vote_average desc limit 1;
### k)	Which movie(s) were directed by Brenda Chapman?
SELECT movies.original_title, directors.name
FROM movies
JOIN directors
WHERE directors.name = 'Brenda Chapman'
limit 5;
### l)	Which director made the most movies?
SELECT directors.name, COUNT(*) AS total_movies
FROM movies
JOIN directors
ON movies.director_id = directors.id
GROUP BY directors.id, directors.name
ORDER BY total_movies DESC
LIMIT 1;
### m)	Which director is the most bankable?
SELECT directors.name, SUM(movies.budget) AS total_budget
FROM movies
JOIN directors
ON movies.director_id = directors.id
GROUP BY directors.id, directors.name
ORDER BY total_budget DESC
LIMIT 1;

